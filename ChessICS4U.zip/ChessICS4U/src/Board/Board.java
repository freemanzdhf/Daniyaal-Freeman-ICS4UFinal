package Board;
import Piece.Bishop;
import Piece.Knight;
import Piece.Pawn;
import Piece.Rook;

public class Board {
	Spot[][] spots; 
	  
    public Board() 
    { 
        
    } 
  
    public Spot getSpot(int x, int y) 
    { 
    	return null;
    } 
  
    public void resetBoard() 
    { 
       
    } 
	
	
	
}
