package Player;
public class AIPlayer extends Player{
	
	// Purpose:
	// Parameters:
	public AIPlayer(boolean white) {
		this.white = white;
		this.human = false;
	}
}
