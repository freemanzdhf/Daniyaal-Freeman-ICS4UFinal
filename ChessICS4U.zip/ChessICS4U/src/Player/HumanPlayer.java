package Player;
public class HumanPlayer extends Player {
	
	// Purpose: 
	// Parameters:
	public HumanPlayer(boolean white) {
		this.white = white;
		this.human = true;
	}

}
