package Player;

public abstract class Player {
	
	// DATA
	public boolean white;
	public boolean human;
	
	// GETTERS
	
	public boolean isWhite() {
		return white;
	}
	
	public boolean isHuman() {
		return human;
	}

}
